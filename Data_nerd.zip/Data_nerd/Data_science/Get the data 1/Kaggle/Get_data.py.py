import kaggle

# Download Titanic dataset and unzip it
kaggle.api.dataset_download_files('heptapod/titanic', path='data/', unzip=True)

print("Dataset downloaded successfully!")